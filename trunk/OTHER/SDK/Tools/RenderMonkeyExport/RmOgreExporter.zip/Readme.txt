Building the RmOgreExporter plugin using MSVC on Windows XP:
____________________________________________________________

  There are 3 environment variables and 3 dependencies to setup so that the project can be built. These environment variables have to be setup before starting the MSVC IDE.

BOOST_PATH has to point to the directory where Boost is installed. You can get Boost from here: 
http://www.boost.org/

RM_PATH has to point to the directory where RenderMonkey is installed. Get RM from here: 
http://www.ati.com/developer/rendermonkey/downloads.html

LOKI_PATH points to the directory where Loki is installed. Get Loki from here:
http://sourceforge.net/projects/loki-lib/

**** NOTE: You do not need to build Boost or Loki since only the templates in the headers are used.

Building in VC7.1 on Windows XP:
________________________________
open RmOgreExporter.sln which is found in RmOgreExporter directory\scripts\VC71

  As long as the 3 dependencies are installed and the 3 environment variables are setup prior to starting the MSVC IDE, the solution should build with no problems.

  There is a release build post-build script that will copy the release build of RmOgreExporter.dll to the RM_PATH\Plugins directory so that after doing a release build you should be able to start RenderMonkey and use the plugin.

Using the plugin:

If unpacking from the rmOgreExporter.zip:
copy all .dll files into PlugIns subfolder of RenderMonkey� 1.6 installation folder. 
Run RenderMonkey�.

In RenderMonkey: 
Open a shader file. 
Get context menu for effect node in the Workspace window.  
Select Export item and then its Ogre Exporter subitem. 
Pick a directory where files to be created. 

Ogre Exporter creates the following types of files: 

.source files contain source code of shaders 
.program files contain Ogre program definitions 
.material files contain Ogre material definitions 

Generated .material file now can be used in any Ogre application. You can freely manipulate it (e.g. you can put .program file content into .material file, but before material definition itself otherwise errors may occur). 

Please note: 

Some rendering states are not supported by Ogre material framework, so warnings are issued during export, if they are used. 

Please, don't use spaces in names of texture files (Ogre cannot handle such files and it is a fundamental issue). 

Don't rely on state changes in one pass to affect other passes in effect. Please, copy all state changes to all passes, because Ogre manages states his own way, and will discard state changes between passes. The technique is shown in Sample/Fur/fur.rfx (you may need this note for complex multipass materials). 
